package com.example.patienttracker.model;

import jakarta.persistence.*;

@Entity
public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String doctor;
    private String date;
    private String time;

    @ManyToOne
    private User user;

    // Getters and Setters
}