package com.example.patienttracker.controller;

import com.example.patienttracker.model.Prescription;
import com.example.patienttracker.repository.PrescriptionRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionController {
    private final PrescriptionRepository repo;
    public PrescriptionController(PrescriptionRepository repo) { this.repo = repo; }

    @PostMapping
    public Prescription add(@RequestBody Prescription p) {
        return repo.save(p);
    }

    @GetMapping
    public List<Prescription> getAll() {
        return repo.findAll();
    }
}