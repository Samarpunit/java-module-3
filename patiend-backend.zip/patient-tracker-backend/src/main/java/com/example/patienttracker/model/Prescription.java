package com.example.patienttracker.model;

import jakarta.persistence.*;

@Entity
public class Prescription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String medicine;
    private String dosage;

    @ManyToOne
    private User user;

    // Getters and Setters
}