package com.example.patienttracker.controller;

import com.example.patienttracker.model.Appointment;
import com.example.patienttracker.repository.AppointmentRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {
    private final AppointmentRepository repo;
    public AppointmentController(AppointmentRepository repo) { this.repo = repo; }

    @PostMapping
    public Appointment book(@RequestBody Appointment a) {
        return repo.save(a);
    }

    @GetMapping
    public List<Appointment> getAll() {
        return repo.findAll();
    }

    @DeleteMapping("/{id}")
    public void cancel(@PathVariable Long id) {
        repo.deleteById(id);
    }
}