package com.example.patienttracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientTrackerApplication {
    public static void main(String[] args) {
        SpringApplication.run(PatientTrackerApplication.class, args);
    }
}